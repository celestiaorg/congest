#!/bin/bash

# CHAIN_ID="congest"
export CHAIN_ID=""
export AWS_DEFAULT_REGION=""
export AWS_ACCESS_KEY_ID=""
export AWS_SECRET_ACCESS_KEY=""
export S3_BUCKET_NAME=""
